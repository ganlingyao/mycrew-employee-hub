---
name: learned-review
description: Review accepted reports
---
Check the accepted report before finalizing.
Recalculate totals from source rows and flag mismatches.
Mark unsupported claims as missing evidence instead of inventing sources.
Return a corrected report and a separate list of checks and unresolved issues.