export default async function workflow(sdk,input) {
  const organized = await sdk.agent('organize',{kind:'employee',employeeId:'ee54b37e-c3cd-409e-9ca8-167e777e2180',version:1},{stage:'organize',task:'整理用户提供的数据、字段、来源和缺失项；保留原值，不得编造。本节点不绘图、不生成网页。',user:input});
  const diagram = await sdk.agent('diagram',{kind:'employee',employeeId:'ee54b37e-c3cd-409e-9ca8-167e777e2180',version:1},{stage:'diagram',task:'依据整理结果编写 Mermaid 源码，调用 cindy-mermaid 的 prepare_mermaid，并返回插件给出的 source 和 markdown；不得声称已通过渲染校验。',organized:organized.text});
  const webpage = await sdk.agent('webpage',{kind:'employee',employeeId:'ee54b37e-c3cd-409e-9ca8-167e777e2180',version:1},{stage:'webpage',task:'依据整理结果和插件返回的 Mermaid source，在当前工作目录生成 report.html，包含数据表、来源、缺失项、图表和离线回退。检查文件存在，返回文件路径与简要说明。',organized:organized.text,diagram:diagram.text});
  return {organized:organized.text,diagram:diagram.text,webpage:webpage.text};
}