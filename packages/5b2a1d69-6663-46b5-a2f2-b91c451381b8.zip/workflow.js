export default async function workflow(sdk, input) {
  const p = sdk.parameters({
    directory: { type: "string", title: "待扫描目录", description: "输入本机文件夹路径，例如 C:/data/project（示例路径无需提前存在）。", required: true, editable: true }
  });
  const scanned = await sdk.tool("scan_files", "cindy-workflow-tools/python",
    { interpreter: "python.exe", source: sdk.script("file_worker"), output: "json", timeoutMs: 60000 },
    { operation: "scan", directory: p.directory });
  const analyzed = await sdk.tool("analyze_files", "cindy-workflow-tools/python",
    { interpreter: "python.exe", source: sdk.script("file_worker"), output: "json", timeoutMs: 60000 },
    { operation: "analyze", files: scanned.result.files });
  return { scan: scanned.result, analysis: analyzed.result };
}
