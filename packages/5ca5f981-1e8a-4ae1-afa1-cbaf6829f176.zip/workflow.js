export default async function workflow(sdk, input) {
  const development = await sdk.agent('website_development', {kind:'employee', employeeId:'761b8a6a-b635-41f6-ae69-c1f238ab5cfc', version:1}, {request: input, instruction: '根据用户提供的演示需求给出网站实现方案或在明确指定的测试目录内实现，不部署、不提交远端。'});
  const testing = await sdk.agent('website_acceptance', {kind:'employee', employeeId:'25a43fda-3f6c-4c52-863c-32c1fbabcf07', version:1}, {request: input, development: development, instruction: '检查前一步产物，输出测试步骤、实际证据、通过项与问题；未执行的测试不得写成通过。'});
  return {development: development, testing: testing};
}