---
name: synthetic
description: Synthetic test only
---
Review fictional examples. No user data.
